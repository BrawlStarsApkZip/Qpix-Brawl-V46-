How to use:

put your files in ContentUpdater/Content

run ContentUpdater/Updater.py

after its done run ContentUpdater/Server.py

if you managed to deleted it by accident here what lastversion.txt should contains

44.226.1...eb0839807af77681468eb25dcb49ac78639e6265